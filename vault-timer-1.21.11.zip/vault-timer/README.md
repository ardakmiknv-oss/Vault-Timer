# Vault Timer (Fabric 1.21.11, client-side)

Watches the vault under your crosshair. When the displayed item is one you ticked in the settings,
it swaps to the right key (optional) and right-clicks for you. Client-only: no server install needed.

Settings: Mod Menu -> Vault Timer -> Configure (or /vaulttimer).
The top "Vault Timer: ON/OFF" button (or /vaulttimer toggle) enables/disables the whole mod.
"Singleplayer: item drops" additionally makes the displayed item part of the loot in your own
singleplayer world (the built-in server runs it). It has no effect on other servers.
Config file: config/vaulttimer.json

## Building the jar
Java 21 + Gradle 9.2+:   gradle build   ->  build/libs/vault-timer-1.0.0.jar  (not the -sources jar)
No Gradle? Push this folder to a GitHub repo: the included workflow (.github/workflows/build.yml)
builds it; run it from the Actions tab and download the "vault-timer-jar" artifact.
