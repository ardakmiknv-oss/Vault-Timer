package dev.vaulttimer.client;

import dev.vaulttimer.VaultTimerConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class VaultTimerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(VaultAutoTimer::tick);
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> VaultAutoTimer.reset());

        // /vaulttimer opens the settings, /vaulttimer toggle flips the master switch
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("vaulttimer")
                        .executes(ctx -> {
                            MinecraftClient mc = ctx.getSource().getClient();
                            mc.send(() -> mc.setScreen(new VaultTimerScreen(null)));
                            return 1;
                        })
                        .then(ClientCommandManager.literal("toggle").executes(ctx -> {
                            VaultTimerConfig cfg = VaultTimerConfig.get();
                            cfg.enabled = !cfg.enabled;
                            VaultAutoTimer.reset();
                            VaultTimerConfig.save();
                            ctx.getSource().sendFeedback(
                                    Text.literal("Vault Timer: " + (cfg.enabled ? "ON" : "OFF")));
                            return 1;
                        }))));
    }
}
