package dev.vaulttimer.client;

import dev.vaulttimer.VaultTarget;
import dev.vaulttimer.VaultTimerConfig;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.VaultBlock;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;

/** Watches the vault under your crosshair and inserts the key the moment a wanted item is on display. */
public final class VaultAutoTimer {
    /** Vaults we already tried this session, so a finished vault is not clicked over and over. */
    private static final Set<BlockPos> attempted = new HashSet<>();

    private VaultAutoTimer() {
    }

    public static void reset() {
        attempted.clear();
    }

    public static void tick(MinecraftClient mc) {
        VaultTimerConfig cfg = VaultTimerConfig.get();
        if (!cfg.enabled || mc.player == null || mc.world == null
                || mc.interactionManager == null || mc.currentScreen != null) {
            return;
        }
        if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
            return;
        }

        BlockPos pos = hit.getBlockPos();
        if (attempted.contains(pos)) {
            return;
        }
        BlockState state = mc.world.getBlockState(pos);
        if (!state.isOf(Blocks.VAULT) || !"active".equals(state.get(VaultBlock.VAULT_STATE).asString())) {
            return;
        }
        if (!(mc.world.getBlockEntity(pos) instanceof VaultBlockEntity vault)) {
            return;
        }

        ItemStack shown = vault.getSharedData().getDisplayItem();
        if (shown.isEmpty()) {
            return;
        }
        boolean ominous = state.get(VaultBlock.OMINOUS);
        VaultTarget match = cfg.matchingTarget(ominous, shown);
        if (match == null) {
            return;
        }

        ClientPlayerEntity player = mc.player;
        Item key = ominous ? Items.OMINOUS_TRIAL_KEY : Items.TRIAL_KEY;
        if (!player.getMainHandStack().isOf(key)) {
            if (!cfg.autoSwapKey) {
                return;
            }
            int slot = findKeySlot(player, key);
            if (slot < 0) {
                return;
            }
            player.getInventory().setSelectedSlot(slot);
        }

        attempted.add(pos.toImmutable());
        mc.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
        player.swingHand(Hand.MAIN_HAND);
        player.sendMessage(Text.literal("Vault Timer: opened on " + match.label), true);
    }

    private static int findKeySlot(ClientPlayerEntity player, Item key) {
        for (int i = 0; i < 9; i++) {
            if (player.getInventory().getStack(i).isOf(key)) {
                return i;
            }
        }
        return -1;
    }
}
