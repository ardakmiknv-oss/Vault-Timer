package dev.vaulttimer.client;

import dev.vaulttimer.VaultTarget;
import dev.vaulttimer.VaultTimerConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Settings screen: opened from Mod Menu (or /vaulttimer). */
public class VaultTimerScreen extends Screen {
    private final Screen parent;
    /** Everything that is greyed out while the mod is disabled. */
    private final List<ButtonWidget> dependents = new ArrayList<>();

    public VaultTimerScreen(Screen parent) {
        super(Text.literal("Vault Timer"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        VaultTimerConfig cfg = VaultTimerConfig.get();
        int cx = this.width / 2;
        dependents.clear();

        // Master enable/disable: turns off both the auto-click and the displayed-item guarantee
        addDrawableChild(toggle(cx - 100, 30, 200, "Vault Timer",
                () -> cfg.enabled,
                on -> {
                    cfg.enabled = on;
                    VaultAutoTimer.reset();
                    dependents.forEach(b -> b.active = on);
                }));

        dependents.add(addDrawableChild(toggle(cx - 100, 54, 200, "Swap to key",
                () -> cfg.autoSwapKey, on -> cfg.autoSwapKey = on)));
        dependents.add(addDrawableChild(toggle(cx - 100, 76, 200, "Singleplayer: item drops",
                () -> cfg.guaranteeDisplayedItem, on -> cfg.guaranteeDisplayedItem = on)));

        int leftX = cx - 155;
        int rightX = cx + 5;
        int y0 = 120;
        for (int i = 0; i < VaultTarget.OMINOUS_VAULT.size(); i++) {
            VaultTarget target = VaultTarget.OMINOUS_VAULT.get(i);
            dependents.add(addDrawableChild(toggle(leftX, y0 + i * 22, 150, target.label,
                    () -> cfg.isSelected(true, target), on -> cfg.setSelected(true, target, on))));
        }
        for (int i = 0; i < VaultTarget.NORMAL_VAULT.size(); i++) {
            VaultTarget target = VaultTarget.NORMAL_VAULT.get(i);
            dependents.add(addDrawableChild(toggle(rightX, y0 + i * 22, 150, target.label,
                    () -> cfg.isSelected(false, target), on -> cfg.setSelected(false, target, on))));
        }

        dependents.forEach(b -> b.active = cfg.enabled);

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(cx - 100, this.height - 28, 200, 20).build());
    }

    private static ButtonWidget toggle(int x, int y, int w, String name,
                                       BooleanSupplier getter, Consumer<Boolean> setter) {
        return ButtonWidget.builder(label(name, getter.getAsBoolean()), button -> {
            boolean now = !getter.getAsBoolean();
            setter.accept(now);
            button.setMessage(label(name, now));
        }).dimensions(x, y, w, 20).build();
    }

    private static Text label(String name, boolean on) {
        return Text.literal(name + ": ")
                .append(Text.literal(on ? "ON" : "OFF").formatted(on ? Formatting.GREEN : Formatting.RED));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        int cx = this.width / 2;
        centered(context, Text.literal("Vault Timer").formatted(Formatting.BOLD), cx, 12);
        centered(context, Text.literal("Ominous vaults"), cx - 80, 106);
        centered(context, Text.literal("Normal vaults"), cx + 80, 106);
    }

    private void centered(DrawContext context, Text text, int centerX, int y) {
        context.drawTextWithShadow(this.textRenderer, text,
                centerX - this.textRenderer.getWidth(text) / 2, y, 0xFFFFFFFF);
    }

    @Override
    public void close() {
        VaultTimerConfig.save();
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
}
