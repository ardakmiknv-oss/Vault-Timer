package dev.vaulttimer;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VaultTimerMod implements ModInitializer {
    public static final String MOD_ID = "vaulttimer";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        VaultTimerConfig.load();
        LOGGER.info("Vault Timer loaded (guaranteeDisplayedItem={})", VaultTimerConfig.get().guaranteeDisplayedItem);
    }
}
