package dev.vaulttimer.mixin;

import dev.vaulttimer.VaultTimerConfig;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.block.vault.VaultConfig;
import net.minecraft.block.vault.VaultServerData;
import net.minecraft.block.vault.VaultSharedData;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Vanilla rolls vault loot independently of the cycling display item, so timing a click does nothing.
 * This makes the display honest: whatever is on show when the key goes in is added to the loot.
 * Runs on the integrated server (singleplayer) and on any server that has this mod installed.
 */
@Mixin(VaultBlockEntity.Server.class)
public abstract class VaultBlockEntityServerMixin {

    @Inject(method = "unlock", at = @At("HEAD"))
    private static void vaulttimer$includeDisplayedItem(
            ServerWorld world, BlockState state, BlockPos pos, VaultConfig config,
            VaultServerData serverData, VaultSharedData sharedData,
            List<ItemStack> itemsToEject, CallbackInfo ci) {

        VaultTimerConfig cfg = VaultTimerConfig.get();
        if (!cfg.enabled || !cfg.guaranteeDisplayedItem) {
            return;
        }
        ItemStack shown = sharedData.getDisplayItem();
        if (shown.isEmpty()) {
            return;
        }
        for (ItemStack rolled : itemsToEject) {
            if (ItemStack.areItemsAndComponentsEqual(rolled, shown)) {
                return; // already getting it
            }
        }
        try {
            itemsToEject.add(0, shown.copy());
        } catch (UnsupportedOperationException ignored) {
            // immutable list: leave vanilla behaviour alone
        }
    }
}
