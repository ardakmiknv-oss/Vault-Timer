package dev.vaulttimer;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.List;

/** Items the player can ask Vault Timer to wait for. */
public enum VaultTarget {
    HEAVY_CORE("Heavy Core"),
    FLOW_ARMOR_TRIM("Flow Armor Trim"),
    CREATOR_MUSIC_DISC("Creator Music Disc"),
    OMINOUS_BOTTLE("Ominous Bottle"),
    WIND_BURST_BOOK("Wind Burst Book"),
    TRIDENT("Trident");

    /** What can be chosen for ominous vaults. */
    public static final List<VaultTarget> OMINOUS_VAULT = List.of(
            HEAVY_CORE, FLOW_ARMOR_TRIM, CREATOR_MUSIC_DISC, OMINOUS_BOTTLE, WIND_BURST_BOOK);

    /** What can be chosen for normal vaults. */
    public static final List<VaultTarget> NORMAL_VAULT = List.of(OMINOUS_BOTTLE, TRIDENT);

    public final String label;

    VaultTarget(String label) {
        this.label = label;
    }

    public boolean matches(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        return switch (this) {
            case HEAVY_CORE -> stack.isOf(Items.HEAVY_CORE);
            case FLOW_ARMOR_TRIM -> stack.isOf(Items.FLOW_ARMOR_TRIM_SMITHING_TEMPLATE);
            case CREATOR_MUSIC_DISC -> stack.isOf(Items.MUSIC_DISC_CREATOR);
            case OMINOUS_BOTTLE -> stack.isOf(Items.OMINOUS_BOTTLE);
            case TRIDENT -> stack.isOf(Items.TRIDENT);
            case WIND_BURST_BOOK -> isWindBurstBook(stack);
        };
    }

    private static boolean isWindBurstBook(ItemStack stack) {
        if (!stack.isOf(Items.ENCHANTED_BOOK)) {
            return false;
        }
        ItemEnchantmentsComponent stored = stack.get(DataComponentTypes.STORED_ENCHANTMENTS);
        if (stored == null) {
            return false;
        }
        for (RegistryEntry<Enchantment> entry : stored.getEnchantments()) {
            if (entry.matchesKey(Enchantments.WIND_BURST)) {
                return true;
            }
        }
        return false;
    }
}
