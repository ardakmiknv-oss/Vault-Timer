package dev.vaulttimer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.item.ItemStack;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Saved to config/vaulttimer.json. Shared by the client GUI and the server mixin (singleplayer). */
public final class VaultTimerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static VaultTimerConfig instance;

    /** Master switch for the auto-click. */
    public boolean enabled = true;
    /** Move the matching trial key to your hand automatically (hotbar only). */
    public boolean autoSwapKey = true;
    /** Server half: make sure the item on display when the key goes in is part of the loot. */
    public boolean guaranteeDisplayedItem = true;

    public Set<String> ominousTargets = new LinkedHashSet<>(List.of(VaultTarget.HEAVY_CORE.name()));
    public Set<String> normalTargets = new LinkedHashSet<>(List.of(VaultTarget.TRIDENT.name()));

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("vaulttimer.json");
    }

    public static synchronized VaultTimerConfig get() {
        if (instance == null) {
            load();
        }
        return instance;
    }

    public static synchronized void load() {
        VaultTimerConfig loaded = null;
        Path file = path();
        if (Files.exists(file)) {
            try {
                loaded = GSON.fromJson(Files.readString(file), VaultTimerConfig.class);
            } catch (Exception e) {
                VaultTimerMod.LOGGER.warn("Could not read {}, using defaults", file, e);
            }
        }
        if (loaded == null) {
            loaded = new VaultTimerConfig();
        }
        if (loaded.ominousTargets == null) {
            loaded.ominousTargets = new LinkedHashSet<>();
        }
        if (loaded.normalTargets == null) {
            loaded.normalTargets = new LinkedHashSet<>();
        }
        instance = loaded;
    }

    public static synchronized void save() {
        if (instance == null) {
            return;
        }
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (IOException e) {
            VaultTimerMod.LOGGER.warn("Could not save config", e);
        }
    }

    private Set<String> setFor(boolean ominous) {
        return ominous ? ominousTargets : normalTargets;
    }

    public boolean isSelected(boolean ominous, VaultTarget target) {
        return setFor(ominous).contains(target.name());
    }

    public void setSelected(boolean ominous, VaultTarget target, boolean on) {
        if (on) {
            setFor(ominous).add(target.name());
        } else {
            setFor(ominous).remove(target.name());
        }
    }

    /** The selected target that the displayed stack satisfies, or null. */
    public VaultTarget matchingTarget(boolean ominous, ItemStack shown) {
        List<VaultTarget> options = ominous ? VaultTarget.OMINOUS_VAULT : VaultTarget.NORMAL_VAULT;
        for (VaultTarget target : options) {
            if (isSelected(ominous, target) && target.matches(shown)) {
                return target;
            }
        }
        return null;
    }
}
